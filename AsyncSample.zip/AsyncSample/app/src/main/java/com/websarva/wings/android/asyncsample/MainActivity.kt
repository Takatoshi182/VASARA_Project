package com.websarva.wings.android.asyncsample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.SimpleAdapter
import android.widget.TextView
import androidx.annotation.UiThread
import androidx.annotation.WorkerThread
import androidx.core.os.HandlerCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    //クラス内のprivate定数を宣言するためにcompanion objectブロックとする
    companion object{
        //ログに記載するタグ用の文字列
        private const val DEBUG_TAG = "AsyncSample"
        //お天気情報のURL
        private  const val WEATHERINFO_URL ="https://api.openweathermap.org/data/2.5/weather?lang=ja"
        //お天気APIにアクセスするためのAPIキー
        private const val APP_ID= "c95ac10cf3e67ff5ee0be19390b83475"
    }

    //リストビューに表示させるリストデータ
    private var _list: MutableList<MutableMap<String,String>> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        _list = createList()

        val lvCityList = findViewById<ListView>(R.id.lvCityList)
        //val lvMenu = findViewById<ListView>(R.id.lvMenu)
        val from = arrayOf("name")
        val to = intArrayOf(android.R.id.text1)
        val adapter = SimpleAdapter(this@MainActivity,_list,
            android.R.layout.simple_list_item_1,from,to)
        lvCityList.adapter = adapter
        lvCityList.onItemClickListener = ListItemClickListener()
        //lvMenu.onItemClickListener = ListItemClickListener()
    }
    //リストビューに表示させる天気ポイントリストデータを生成するメソッド
    private fun createList():MutableList<MutableMap<String,String>>{
        val list: MutableList<MutableMap<String,String>> = mutableListOf()
        var city = mutableMapOf("name" to "札幌","q" to "Sapporo")
        list.add(city)
        city = mutableMapOf("name" to "仙台","q" to "Sendai")
        list.add(city)
        city = mutableMapOf("name" to "東京","q" to "Tokyo")
        list.add(city)
        city = mutableMapOf("name" to "名古屋","q" to "Nagoya")
        list.add(city)
        city = mutableMapOf("name" to "大阪","q" to "Osaka")
        list.add(city)
        city = mutableMapOf("name" to "広島","q" to "Hiroshima")
        list.add(city)
        city = mutableMapOf("name" to "高松","q" to "Takamatsu")
        list.add(city)
        city = mutableMapOf("name" to "福岡","q" to "Fukuoka")
        list.add(city)

        return list
    }
    //お天気情報の取得処理を行うメソッド
    @UiThread
    private fun receiveWeatherInfo(urlFull:String){
        //ここに非同期で天気情報を取得する処理を記述。
        val handler = HandlerCompat.createAsync(mainLooper)
        val backgroundReceiver = WeatherInfoBackgroundReceiver(handler,urlFull)
        val executeService = Executors.newSingleThreadExecutor()
        executeService.submit(backgroundReceiver)
    }

    //非同期で天気情報APIにアクセスするためのクラス
    private inner class WeatherInfoBackgroundReceiver(handler: Handler,
        url:String): Runnable{
        //ハンドラオブジェクト
        private val _handler = handler
        //天気情報を取得するURL
        private val _url = url
        @WorkerThread
        override fun run(){
            //天気情報サービスから取得したJSON文字列。天気情報が格納されている
            var result = ""
            //URLオブジェクトを生成
            val url = URL(_url)
            //URLオブジェクトからHttpURLConnectionオブジェクトを取得
            val con = url.openConnection() as? HttpURLConnection
            //conがnullじゃなければ
            con?.let{
                try{
                    //接続に使ってもよい時間を設定
                    it.connectTimeout = 1000
                    //データ取得に使ってもよい時間
                    it.readTimeout = 1000
                    //HTTP接続メソッドをGETに設定
                    it.requestMethod = "GET"
                    //接続
                    it.connect()
                    //HttpURLConnectionオブジェクトからレスポンスデータを取得
                    val stream = it.inputStream
                    //レスポンスデータであるInputStreamを文字列に変換
                    result = is2String(stream)
                    //InputStreamオブジェクトを解放
                    stream.close()
                }
                catch(ex: SocketTimeoutException){
                    Log.w(DEBUG_TAG,"通信タイムアウト",ex)
                }
                //HttpURLConnectionオブジェクトを解放
                it.disconnect()
            }
            //ここにwebAPIにアクセスするためのコードを記述
            val postExecutor = WeatherInfoPostExecutor(result)
            _handler.post(postExecutor)
        }
        private fun is2String(stream: InputStream):String{
            val sb = StringBuilder()
            val reader = BufferedReader(InputStreamReader(stream,"UTF-8"))
            var line = reader.readLine()
            while(line != null){
                sb.append(line)
                line = reader.readLine()
            }
            reader.close()
            return sb.toString()
        }
    }

    //非同期で天気情報を取得した後にUIスレッドでその情報を表示するためのクラス
    private inner class WeatherInfoPostExecutor(result:String):Runnable{
        //取得した天気情報JSON文字列
        private val _result = result
        @UiThread
        override fun run(){
            //ここにUIスレッドで行う処理コードを記述
            //ルートJSONオブジェクトを生成
            val rootJSON = JSONObject(_result)
            //都市名文字列を取得
            val cityName = rootJSON.getString("name")
            //緯度経度情報JSONオブジェクトを取得
            val coordJSON = rootJSON.getJSONObject("coord")
            //気温情報JSONオブジェクト取得
            val mainJSON = rootJSON.getJSONObject("main")
            //緯度情報文字列を取得
            val latitude = coordJSON.getString("lat")
            //経度情報文字列を取得
            val longitude = coordJSON.getString("lon")
            //最高気温取得
            val tempMax= mainJSON.getString("temp_max")
            //最低気温取得
            val tempMin= mainJSON.getString("temp_min")
            //天気情報JSON配列オブジェクトを取得
            val weatherJSONArray = rootJSON.getJSONArray("weather")
            //現在の天気情報JSON配列オブジェクトを取得
            val weatherJSON = weatherJSONArray.getJSONObject(0)
            //現在の天気情報文字列を取得
            val weather = weatherJSON.getString("description")

            //画面に表示する[〇〇の天気]文字列を生成
            val telop = "${cityName}の天気"
            //天気の詳細情報を表示する文字列を生成
            val desc = "現在は${weather}です。/n最高気温は${tempMax}度です。" +
                    "/n最低気温は${tempMin}度です"

            //天気情報を表示するTextView取得
            val tvWeatherTelop = findViewById<TextView>(R.id.tvWeatherTelop)
            val tvWeatherDesc = findViewById<TextView>(R.id.tvWeatherDesc)
            //天気情報を表示
            tvWeatherTelop.text = telop
            tvWeatherDesc.text = desc
        }
    }
    //リストがタップされたときの処理が記述されたリスナクラス
    private inner class ListItemClickListener:AdapterView.OnItemClickListener{
        override  fun onItemClick(parent: AdapterView<*>, view: View, position:Int, id:Long){
            val item = _list.get(position)
            val q = item.get("q")
            q?.let{
                val urlFull ="$WEATHERINFO_URL&q=$q&appid=$APP_ID"
                receiveWeatherInfo(urlFull)
            }
        }
    }
}